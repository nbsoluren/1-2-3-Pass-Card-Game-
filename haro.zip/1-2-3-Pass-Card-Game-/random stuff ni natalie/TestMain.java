import gameUi.Card;
public class TestMain{
  public static void main (String[] arg){
    Card testCard = new Card("Hearts","10");
    Card testCard2 = new Card("Diamond","J");
    Card testCard3 = new Card("Diamond","1");
    System.out.println("WAOR");
  }
}
